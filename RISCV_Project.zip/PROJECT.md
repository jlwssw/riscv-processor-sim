# Project: A RISC-V Processor and Memory System

CS 5375, Computer Systems Organization and Architecture

## The idea

A computer architecture course walks up the stack one layer at a time: how
numbers are represented and computed, how an instruction set is encoded, how a
datapath executes one instruction, how pipelining overlaps many, and how the
memory hierarchy feeds it all. This project builds a *working software model*
of each of those layers in Python, so every concept in the course is something
you can run, inspect, and test, not just draw on paper.

Each phase is self-contained, has its own tests, and plugs into the next.

## Phases and status

| Phase | Layer | Files | Status |
|-------|-------|-------|--------|
| 0 | ISA, assembler, functional CPU | `riscv_sim.py`, `a3_problem1.s`, `a3_problem2.s`, `test_a3.py` | Done (16/16 tests) |
| 1 | Arithmetic & the ALU | `alu.py`, `alu_test.py` | Done (57,792/57,792 tests) |
| 2 | Single-cycle datapath | `datapath.py`, `datapath_test.py` | Done (7/7, cross-checked vs Phase 0) |
| 3 | 5-stage pipeline + hazards | `pipeline.py`, `pipeline_test.py` | Done (6/6, forwarding + stalls + flushes, CPI reported) |
| 4 | Memory hierarchy / cache | `cache_sim.py`, `cache_demo.py`, integrated in `pipeline.py` | Done (reproduces A7; observes live streams) |
| 5 | Performance analysis & report | `perf.py`, `PROJECT_REPORT.md` | Done (benchmark suite, speedup, Amdahl) |

All six phases complete. The full write-up is in `PROJECT_REPORT.md`.

## What each phase teaches

Phase 0: Instruction set and functional simulator.
Assembly is translated into real 32-bit machine code, then executed by a
fetch/decode/execute loop. Covers instruction formats, addressing, branches,
procedures, and the calling convention. Demonstrated on Assignment 3.

Phase 1: The ALU.
The processor's calculator. Addition is built from single-bit *full adders*
wired into a ripple-carry chain (not Python `+`), subtraction reuses the adder
through two's complement, and the unit also does AND/OR/XOR/NOR, shifts, and
signed/unsigned set-less-than. It reports the zero, carry, overflow, and
negative flags that branch and comparison logic depend on. A single ALU-control
code selects the operation, which is the exact wire the control unit drives in
Phase 2.

Phase 2: Single-cycle datapath.
Re-express execution as explicit hardware blocks: a program counter, instruction
memory, register file, sign-extend unit, the Phase-1 ALU, data memory, and the
multiplexers between them, all coordinated by a control unit that reads the opcode
and asserts control signals. Deliverable includes the control-signal truth table
for each instruction type.

Phase 3: Pipelining.
Split the datapath into five stages (IF, ID, EX, MEM, WB) separated by pipeline
registers so five instructions are in flight at once. Add hazard detection,
forwarding (bypassing), stalls for load-use hazards, and branch handling, then
compare CPI against the single-cycle design.

Phase 4: Memory hierarchy.
A cache (direct-mapped, set-associative, fully-associative; LRU) sits between the
CPU and memory. Standalone it reproduces Assignment 7; integrated, it measures the
hit/miss behavior and AMAT of the actual assembly programs the CPU runs.

Phase 5: Performance analysis.
Tie it together: instruction mix, CPI, speedup, Amdahl's law, and a small
benchmark suite run across the single-cycle, pipelined, and cached models, with a
final report.

## How to run (what exists so far)

```
python riscv_sim.py a3_problem1.s     # Phase 0: run a program, dump registers
python test_a3.py                     # Phase 0: CPU/assembler tests   (16/16)
python alu_test.py                    # Phase 1: ALU tests             (57,792/57,792)
python datapath.py --table            # Phase 2: print control-signal table
python datapath.py a3_problem2.s --trace   # Phase 2: run, show control signals
python datapath_test.py               # Phase 2: cross-check vs Phase 0 (7/7)
python pipeline.py a3_problem1.s --trace   # Phase 3: run pipelined, show stalls/flushes
python pipeline_test.py               # Phase 3: cross-check + CPI report (6/6)
python cache_demo.py                  # Phase 4: Assignment 7 cache demonstration
```

## Note on testing

Every phase ships with an automated test file, and all current phases pass:
Phase 0 (16/16), Phase 1 (57,792/57,792), Phase 2 (7/7, cross-checked register-for-
register against the Phase-0 simulator), Phase 3 (6/6, pipeline output identical to
single-cycle, with CPI reported), and the Phase-4 cache reproduces the Assignment 7
hit counts.
